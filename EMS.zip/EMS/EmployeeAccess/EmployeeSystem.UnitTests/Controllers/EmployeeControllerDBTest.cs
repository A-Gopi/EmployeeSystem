﻿using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using EmployeeSystem.Model;
using EmployeeSystem.BL;

namespace EmployeeSystem.Tests.Controllers
{
    [TestClass]
    public class EmployeeControllerDBTest
    {
        IList<EmployeeModel> employee = null;
        EmployeeRepository employeeRepository;

        [TestInitialize]
        public void Setup()
        {
            employeeRepository = new EmployeeRepository();
        }

        [TestMethod]
        public void GetAllEmployees()
        {
            employee = employeeRepository.GetAllEmployees();
            Assert.IsNotNull(employee);
        }

        [TestMethod]
        public void GetEmployeeId()
        {
            employee = employeeRepository.GetEmployeeById(3);
            Assert.IsNotNull(employee);
            Assert.AreEqual(3, employee[0].EmployeeId);
        }

        [TestMethod]
        public void GeEmployeeNotFound()
        {
            employee = employeeRepository.GetEmployeeById(14);
            Assert.AreEqual(0, employee.Count);
            Assert.IsInstanceOfType(employee, typeof(IList<EmployeeModel>));
        }

        [TestMethod]
        public void AddEmployeeTestSuccess()
        {
            EmployeeModel employee = new EmployeeModel
            {
                EmployeeId = 8,
                EmployeeName = "Kumar",
                Location = "Hyderabad",
                Salary = 2000
            };
            int i = employeeRepository.AddEmployee(employee);
            Assert.IsNotNull(i);
        }

        [TestMethod]
        public void UpdateEmployeeTestSuccess()
        {
            EmployeeModel employee = new EmployeeModel
            {
                EmployeeId = 8,
                EmployeeName = "KumarModified",
                Location = "Chennai",
                Salary = 2000
            };
            int i = employeeRepository.UpdateEmployee(employee);
            Assert.IsNotNull(i);
        }

        [TestMethod]
        public void DeleteEmployeeTestSuccess()
        {
            int i = employeeRepository.Delete(8);
            Assert.IsNotNull(i);
            Assert.AreEqual(1, i);
        }

        [TestMethod]
        public void DeleteEmployeeTestNotFound()
        {
            int i = employeeRepository.Delete(14);
            Assert.IsNotNull(i);
            Assert.AreEqual(0, i);
        }
    }
}
