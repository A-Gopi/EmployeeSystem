﻿using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using EmployeeSystem.Model;
using EmployeeSystem.BAL;

namespace EmployeeSystem.Tests.Controllers
{
    [TestClass]
    public class EmployeeControllerTest
    {
        IList<EmployeeModel> employee = null;
        IEmployee iEmployee;

        [TestInitialize]
        public void Setup()
        {
            iEmployee = new EmployeeSystem.BAL.Employee();
        }

        [TestMethod]
        public void GetAllEmployeesTest()
        {
            employee = iEmployee.GetAllEmployees();
            Assert.IsNotNull(employee);
        }

        [TestMethod]
        public void GetEmployeeSuccess()
        {
            employee = iEmployee.GetEmployeeById(3);
            Assert.IsNotNull(employee);
            Assert.AreEqual(3, employee[0].EmployeeId);
        }

        [TestMethod]
        public void GetEmployeeNotFound()
        {
            employee = iEmployee.GetEmployeeById(10);
            Assert.AreEqual(0, employee.Count);
            Assert.IsInstanceOfType(employee, typeof(IList<EmployeeModel>));
        }

        [TestMethod]
        public void AddEmployeeTestSuccess()
        {
            EmployeeModel employee = new EmployeeModel
            {
                EmployeeId = 9,
                EmployeeName = "Ajay2",
                Location = "Chennai2",
                Salary = 2000
            }; 
            int i = iEmployee.AddEmployee(employee);
            Assert.IsNotNull(i);
        }

        [TestMethod]
        public void UpdateEmployeeTestSuccess()
        {
            EmployeeModel employee = new EmployeeModel
            {
                EmployeeId = 9,
                EmployeeName = "AjayModified",
                Location = "Chennai2",
                Salary = 2000
            };
            int i = iEmployee.UpdateEmployee(employee);
            Assert.IsNotNull(i);
        }

        [TestMethod]
        public void DeleteEmployeeTestSuccess()
        {
            int i = iEmployee.Delete(9);
            Assert.IsNotNull(i);
            Assert.AreEqual(1, i);
        }

        [TestMethod]
        public void DeleteEmployeeTestNotFound()
        {
            int i = iEmployee.Delete(6);
            Assert.IsNotNull(i);
            Assert.AreEqual(0, i);
        }
    }
}
