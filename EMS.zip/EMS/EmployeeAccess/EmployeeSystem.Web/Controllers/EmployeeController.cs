﻿using EmployeeSystem.Model;
using EmployeeSystem.BAL;
using System;
using System.Collections.Generic;
using System.Net;
using System.Web.Http;

namespace Employee.Controllers
{
    public class EmployeeController : ApiController
    {
        private IEmployee iEmployee;

        public EmployeeController(IEmployee _iEmployee)
        {
            iEmployee = _iEmployee;
        }

        [Route("api/Employee/FetchAllEmployees")]
        [HttpGet]
        public IHttpActionResult GetAllEmployees()
        {           
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest("InValid Data.");

                IList<EmployeeModel> employee = null;
                employee = iEmployee.GetAllEmployees();
               
                if (employee.Count == 0)
                {
                    return NotFound();
                }
                return Ok(employee);
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        [HttpGet]
        public IHttpActionResult GetEmployeeDetails(int employeeId)
        {      
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest("InValid Data.");

                if (employeeId <= 0)
                    return BadRequest("Please provide valid Employee Id");

                IList<EmployeeModel> employee = null;
               employee= iEmployee.GetEmployeeById(employeeId);               

                if (employee.Count == 0)
                {
                    return NotFound();
                }

                return Ok(employee);
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        [HttpPost]
        public IHttpActionResult AddEmployee(EmployeeModel employee)
        {            
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest("InValid Data.");

                var i = iEmployee.AddEmployee(employee);
                if (i > 0)
                {
                    //return Created("Employee Added Successfully", employee);
                    return Ok("Employee Added Successfully");
                }
                else
                {
                    return StatusCode((HttpStatusCode) 500);
                }
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        [Route("api/Employee/UpdateEmployee")]
        [HttpPut]
        public IHttpActionResult UpdateEmployee(EmployeeModel employee)
        {
            try
            {
                if (employee.EmployeeId <= 0)
                    return BadRequest("Employee id is not valid");

                var i = iEmployee.UpdateEmployee(employee);
                if (i > 0)
                {
                    return Ok("Updated Successfully");
                }
                else
                {
                    return InternalServerError();
                }
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        [HttpDelete]
        public IHttpActionResult Delete(int employeeId)
        {          
            if (employeeId <= 0)
                return BadRequest("Employee id is not valid");

            var employee = iEmployee.GetEmployeeById(employeeId);
            if (employee.Count<1)
            {
                return NotFound();
            }

            var i = iEmployee.Delete(employeeId);
            if (i > 0)
            {
                return StatusCode(HttpStatusCode.NoContent);
                //return Ok("Employee deleted successfully");
            }
            else
            {
                return InternalServerError();
            }
        }
    }
}
