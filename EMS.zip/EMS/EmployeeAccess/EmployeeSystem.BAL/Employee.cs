﻿using EmployeeSystem.BL;
using EmployeeSystem.Model;
using System;
using System.Collections.Generic;

namespace EmployeeSystem.BAL
{
    public class Employee : IEmployee
    {
        public IList<EmployeeModel> GetAllEmployees()
        {
            IList<EmployeeModel> employee = null;
            try
            {
                EmployeeRepository emprepo = new EmployeeRepository();
                employee = emprepo.GetAllEmployees();
                return employee;
            }
            catch (Exception)
            {
                return employee;
            }
        }

        public IList<EmployeeModel> GetEmployeeById(int employeeId)
        {
            IList<EmployeeModel> employee = null;
            try
            {
                EmployeeRepository emprepo = new EmployeeRepository();
                employee = emprepo.GetEmployeeById(employeeId);

                return employee;
            }
            catch (Exception)
            {
                return employee;
            }
        }

        public int AddEmployee(EmployeeModel employee)
        {
            try
            {
                EmployeeRepository emprepo = new EmployeeRepository();
                return emprepo.AddEmployee(employee);
            }
            catch (Exception)
            {
                return 0;
            }
        }

        public int UpdateEmployee(EmployeeModel employee)
        {
            try
            {
                EmployeeRepository emprepo = new EmployeeRepository();
                return emprepo.UpdateEmployee(employee);
            }
            catch (Exception)
            {
                return 0;
            }
        }

        public int Delete(int employeeId)
        {
            try
            {
                EmployeeRepository emprepo = new EmployeeRepository();
                return emprepo.Delete(employeeId);
            }
            catch (Exception)
            {
                return 0;
            }
        }
    }
}
