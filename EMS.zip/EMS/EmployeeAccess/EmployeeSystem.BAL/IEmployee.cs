﻿using System.Collections.Generic;
using EmployeeSystem.Model;

namespace EmployeeSystem.BAL
{
    public interface IEmployee
    {
        IList<EmployeeModel> GetAllEmployees();
        IList<EmployeeModel> GetEmployeeById(int employeeId);
        int AddEmployee(EmployeeModel employee);
        int UpdateEmployee(EmployeeModel employee);
        int Delete(int employeeId);
    }
}
