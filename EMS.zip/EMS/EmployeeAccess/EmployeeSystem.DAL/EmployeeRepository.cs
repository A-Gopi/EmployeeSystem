﻿using System;
using System.Collections.Generic;
using System.Linq;
using Employee.Data;
using EmployeeSystem.Model;
namespace EmployeeSystem.BL
{
    public class EmployeeRepository
    {
        private EmployeeDBEntities entities;

        public EmployeeRepository() 
        {
            entities = new EmployeeDBEntities();
        }

        public IList<EmployeeModel> GetAllEmployees()
        {
            IList<EmployeeModel> employee = null;
            try
            {
                employee = entities.TblEmployees
                                          .Select(s => new EmployeeModel()
                                          {
                                              EmployeeId = s.EmployeeId,
                                              EmployeeName = s.EmployeeName,
                                              Location = s.Location,
                                              Salary = s.Salary
                                          }).ToList<EmployeeModel>();
                return employee;
            }
            catch (Exception)
            {
                return employee;
            }
        }

        public IList<EmployeeModel> GetEmployeeById(int employeeId)
        {

            IList<EmployeeModel> employee = null;
            try
            {
                employee = entities.TblEmployees.Where(x => x.EmployeeId == employeeId)
                                      .Select(s => new EmployeeModel()
                                      {
                                          EmployeeId = s.EmployeeId,
                                          EmployeeName = s.EmployeeName,
                                          Location = s.Location,
                                          Salary = s.Salary
                                      }).ToList<EmployeeModel>();
                return employee;
            }
            catch (Exception)
            {

                return employee;
            }
        }

        public int AddEmployee(EmployeeModel employee)
        {
            try
            {
                entities.TblEmployees.Add(new TblEmployee()
                {
                    EmployeeId = employee.EmployeeId,
                    EmployeeName = employee.EmployeeName,
                    Location = employee.Location,
                    Salary = employee.Salary
                });

                return entities.SaveChanges();
            }
            catch (Exception)
            {
                return 0;
            }
        }

        public int UpdateEmployee(EmployeeModel employeeToUpdate)
        {
            try
            {
                var employee = entities.TblEmployees
                           .Where(s => s.EmployeeId == employeeToUpdate.EmployeeId)
                           .FirstOrDefault();

                if (employee != null)
                {
                    employee.EmployeeName = employeeToUpdate.EmployeeName;
                    employee.Location = employeeToUpdate.Location;
                    employee.Salary = employeeToUpdate.Salary;
                    return entities.SaveChanges();
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception)
            {
                return 0;
            }
        }

        public int Delete(int employeeId)
        {
            try
            {
                var employee = entities.TblEmployees
                           .Where(s => s.EmployeeId == employeeId)
                           .FirstOrDefault();

                if (employee != null)
                {
                    entities.TblEmployees.Remove(employee);
                    return entities.SaveChanges();
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception)
            {
                return 0;
            }
        }
    }
}
