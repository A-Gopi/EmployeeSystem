﻿namespace EmployeeSystem.Model
{
    public class EmployeeModel
    {
        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public string Location { get; set; }
        public decimal? Salary { get; set; }
    }
}
